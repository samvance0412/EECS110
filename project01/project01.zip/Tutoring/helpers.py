from utilities import *


# def make_creature(canvas, center, size=100, tag='creature', fill='hotpink'):
# just a demo of how you might think about making your creature:
# left_eye_pos = (center[0] - size / 4, center[1] - size / 5)
# right_eye_pos = (center[0] + size / 4, center[1] - size / 5)
# eye_width = eye_height = size / 10
# utilities.make_circle(canvas, center, size, color=fill, tag=tag)
# utilities.make_oval(canvas, left_eye_pos, eye_width,
#                   eye_height, color='black', tag=tag)
# utilities.make_oval(canvas, right_eye_pos, eye_width,
#                   eye_height, color='black', tag=tag)
# utilities.make_line(canvas, [
#    (center[0] - size / 2, center[1] + size / 3),
#   (center[0], center[1] + size / 1.2),
#  (center[0] + size / 2, center[1] + size / 3)
# ], curvy=True)


def make_landscape_object(canvas, position, size=100):
    # your code to create your creature goes here:
    return


def make_creature(canvas, center, width=100, primary_color="grey", secondary_color="#000000"):
    make_oval(canvas, (210, 750), 13, 28, color=secondary_color)
    make_oval(canvas, (260, 750), 13, 28, color=secondary_color)
    make_circle(canvas, (260, 620), 140, color=primary_color, stroke_width=0)
    make_oval(canvas, (180, 760), 15, 30, color=secondary_color)
    make_oval(canvas, (290, 760), 15, 30, color=secondary_color)

    make_oval(canvas, (260, 580), 85, 77, color="white", stroke_width=0)
    # canvas.create_oval(
    #     [
    #         (center[0]-190, center[1]-240),
    #         (center[0]+80, center[1]+20)  # main body circle
    #     ],
    #     fill=primary_color
    # )
    # canvas.create_oval(
    #     [
    #         (center[0]-190, center[1]-170),
    #         (center[0]+40, center[1]-20)  # face
    #     ],
    #     fill="white"
    # )
    # canvas.create_oval(
    #     [
    #         (center[0]-110, center[1]-20),
    #         (center[0]-90, center[1]+20)  # front left foot
    #     ],
    #     fill=secondary_color
    # )
    # canvas.create_oval(
    #     [
    #         (center[0]-20, center[1]-20),
    #         (center[0], center[1]+20)  # front right foot
    #     ],
    #     fill=secondary_color
    # )

    # canvas.create_oval(
    #     [
    #         center,
    #         center[0]+50, center[1]+100  # bottom right  # top left
    #     ],
    #     fill=secondary_color
    # )

    # canvas.create_oval(
    #     [
    #         center,  # top left
    #         center[0]+200, center[1]+200  # bottom right
    #     ],
    #     fill=primary_color
    # )

    # canvas.create_oval(
    #     [
    #         (250, 200),  # top left
    #         (300, 300)  # bottom right
    #     ],
    #     fill=secondary_color
    # )

    # canvas.create_oval(
    #     [
    #         (215, 110),  # top left
    #         (235, 145)  # bottom right
    #     ],
    #     fill='white'
    # )
    # canvas.create_oval(
    #     [
    #         (265, 110),  # top left
    #         (285, 145)  # bottom right
    #     ],
    #     fill='white'
    # )
    # # replace the code below...
    # print('make_landscape_object...')
    # #print('size:', size, 'center:', position)

    # canvas.create_arc(150, 150, 300, 150, extent=180, fill="red")
