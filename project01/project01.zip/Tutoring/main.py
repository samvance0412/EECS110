from tkinter import Canvas, Tk
from helpers import *
from utilities import *
import time

gui = Tk()
gui.title('My Terrarium')

# initialize canvas:
window_width = gui.winfo_screenwidth()
window_height = gui.winfo_screenheight()


canvas = Canvas(gui, width=window_width,
                height=window_height, background='white')
canvas.pack()

make_image(canvas, "background.png", size=(
    window_width, window_height), position=(0, 0))


########################## YOUR CODE BELOW THIS LINE ##############################

# sample code to make a creature:

# make_landscape_object(canvas, (450, 400), size=20)
make_creature(canvas, (650, 350), primary_color="grey",
              secondary_color="#000000")
# make_creature(canvas, (1000, 550), primary_color="black",
#               secondary_color="white")
# make_creature(canvas, (1300, 350), primary_color="purple",
#               secondary_color="pink")
#make_grid(canvas, screen_width, screen_height)


########################## YOUR CODE ABOVE THIS LINE ##############################

# makes sure the canvas keeps running:
canvas.mainloop()
