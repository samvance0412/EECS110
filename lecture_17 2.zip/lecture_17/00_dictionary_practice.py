import helpers
import pprint
import json


file_path = helpers.get_file_path('artists.json', subdirectory='data_sources')
f = open(file_path, 'r')
artists = json.load(f)
# pprint.pprint(artists)

print(artists)


'''
Challenges: 
1. Print the name of the third artist in the list
2. Print the url that is associated with the image for the second artist
3. Build a list of image urls
4. Print the name of all of the artists
'''


# print(artists[2]["name"])
# print(artists[1]['image']["url"])
# list_url = []
# for i in range(0,len(artists)): #rangge does not inlcude last index
#     list_url.append(artists[i]['image']['url'])
# print(list_url)

for artist in artists:
    try:
        print(['genres'][3])
    except: 
        print('artists doesnt have a fourth genre')

# print(artists[0]["name"],[1]["name"],[2]["name"])

# second_artist = artists[1]
# image_dict = second_artist['image']